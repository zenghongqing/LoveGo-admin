exports.port = process.env.PORT || 3000
exports.mongodb = 'mongodb://localhost/LoveGo-admin'
exports.baseApi = '/api'
